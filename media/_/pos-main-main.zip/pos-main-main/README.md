![Free laravel point of sale pos download](https://1.bp.blogspot.com/-G5gASdD5He8/Xt4Ct4Au9qI/AAAAAAAAJ5A/ab3TbJB9ESIm4gQLWdbyd3ihfnxgAc70gCK4BGAsYHg/s1200/kasir%2Binvoice%2Bonline%2Bweb%2Bapp.jpg)

# LARAVEL POS WITH INVOICE Z-INVOICE APPS

<a href="https://www.buymeacoffee.com/axcora"><img width="240" src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgIA9HMwkK8kr7uRwVNxnhXsLQsJHxQQYVSzqCAaK58OpJOiTlzbIX7eEwS_VpJ3oEG-xrmVEl2WKqGvB_o-KjyBGTbbjFHM_bN2Jce9g3FTnt2ZJViwcvB9DHPOKPEMCl7jTQRVWKPw_ETloH7_CK8Xr09SSNNx22xnfGjViwdEsGtR-yGrLmr-JUGHA/s1090/bmc-button.png"/></a>


Test Drive a demo [https://axcora.my.id/laravelpos/](https://axcora.my.id/laravelpos/)

Artisan php apps with point of sale management and invoice features. with [laravel](https://laravel.com)

For full installation and documentation visit here :
[https://www.hockeycomputindo.com/2020/09/aplikasi-toko-gratis-download.html](https://www.hockeycomputindo.com/2020/09/aplikasi-toko-gratis-download.html)

![Free laravel point of sale pos download](https://1.bp.blogspot.com/-e-bpBfO1Auo/Xt4CtfTVBQI/AAAAAAAAJ48/devpdRdDYeEmFoupaglHSaQXBbIuEeU0QCK4BGAsYHg/s1000/app%2Btoko%2Bkasir%2Binvoice%2Bonline.jpg)

Complete with modern UI , Free download and Open source code.

![Mobile Apps](https://1.bp.blogspot.com/-VFexNgv0VpQ/Xt4CurpWzOI/AAAAAAAAJ5E/lWAvlzowclEhNh6SpjPQ2CcTbOJnDuLAgCK4BGAsYHg/s1500/mesin%2Bkasir%2Bonline%2Bzinvoice.jpg)

Can be install on offline desktop or Clouds and upload it on your shared hosting for mobile apps integration with android smartphone or iphone.

![Laravel pos Backoffice](https://1.bp.blogspot.com/-uoz9QrY33ag/Xt4CsqYprdI/AAAAAAAAJ44/Pv9yrCoB49ANxXFMiL2SmCyrwQDOhQG2gCK4BGAsYHg/s1000/aplikasi%2Bkasir%2Binvoice%2Bonline%2Bzinvoice.jpg)

Fast and stable with laravel php artisan serve.


----------------------------------------------------------------------------------------------

### Update 

![Laravel point of sale](img/update1.jpg)

New update

![Laravel point of sale](img/update2.jpg)

Update new

![Laravel point of sale](img/update3.png)

Pos Cashier Transaction

------------------------------------

create mysql db or sqlite db

configure db .env

`composer install`

`composer update`

`php artisan migrate`

`php artisan db:seed`

`php artisan serve`

`open localhost:8000`

----------------------------------------------------------------------------------------------


## A freatures : 

![Free download source code Laravel pos](/img/Screenshot_2020-05-27%20Z%20POS%20Web%20Apps.png)

Login with username and password , by default user name : admin@admin.com , password : 12345678

![Free download source code Laravel pos](/img/Screenshot_2020-05-27%20INVOICE%20ONLINE.png)

Home page menu.

![Free download source code Laravel pos](/img/Screenshotsa_2020-05-27%20INVOICE%20ONLINE.png)

User databased for create and register user account.

![Free download source code Laravel pos](/img/Screenshot_2020-05-27%20INVOICE%20ONLINE(1).png)

Customer databased for register customer.

![Free download source code Laravel pos](/img/Screenshot_2020-05-27%20INVOICE%20ONLINE(2).png)

Product group and categories.

![Free download source code Laravel pos](/img/Screenshot_2020-05-27%20INVOICE%20ONLINE(3).png)

Master Product databased.

![Free download source code Laravel pos](/img/Screenshot_2020-05-27%20INVOICE%20ONLINE(5).png)

Point of sale transaction.

![Free download source code Laravel pos](/img/Screenshot_2020-05-27%20INVOICE%20ONLINE(7).png)

Print invoice with letter format or you can print with receipt print, you can print with two print out method with you needed.

![Free download source code Laravel pos](/img/Screenshot_2020-05-27%20INVOICE%20ONLINE(6).png)

Report detailed for check transaction, and you can export report detailed.

----------------------------------------------------------------------------------------------

## How to install ?? [Cek video installation →](https://youtu.be/V6xW1EEwLcs)

For first you need download third party apps for using laravel point of sale with invoice system.

XAMPP for apache web server and mysql databased [Download here →](https://www.apachefriends.org/download.html)

Composer  [Download here →](https://getcomposer.org/download/)

Git Bash [Download here →](https://git-scm.com/downloads)

Download and install all third party apps.

Run xampp apache and mysql server , and create new databased rename with lapos

Download this apps, or clone/fork it 


----------------------------------------------------------------------------------------------


### Option 1: 

git clone https://github.com/mesinkasir/larapos.git

now on your project folder , right click and select git bash here.

and run command : 

composer install && php artisan migrate && php artisan db:seed && php artisan key:generate && php artisan serve

Open localhost:8000 on web browser and get started with laravel pos apps.

now you can view a laravel point of sale with invoice system web apps , just click on get started button and login to apps.

username : admin@admin.com / password : 12345678.


----------------------------------------------------------------------------------------------

### Option 2: 

Download and Extract Zip file download to your project folder, open localhost/phpmyadmin and select lapos on phpmyadmin , then click on import databased , upload zinvoice.sql if you wan to use apps include demo data, or select zinvoice - emptydb.sql if you need empty databased.

back to project folder again, and right click then select git bash here.

run command : 

composer install && php artisan key:generate && php artisan serve

Open localhost:8000 on web browser and get started with laravel pos apps.

now you can view a laravel point of sale with invoice system web apps , just click on get started button and login to apps.

username : admin@admin.com / password : 12345678.



### Enjoy it and hapy codding, be artisan with laravel php artisan.


Test Drive a demo [https://axcora.my.id/laravelpos/](https://axcora.my.id/laravelpos/)

For full installation and documentation visit here :
[https://www.hockeycomputindo.com/2020/09/aplikasi-toko-gratis-download.html](https://www.hockeycomputindo.com/2020/09/aplikasi-toko-gratis-download.html)



--------------------------------------------------------------------------------------------------------------------

### Buy me a coffee ☕️ ❤️  ✌🏻 

<a href="https://www.buymeacoffee.com/axcora"><img width="240" src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgIA9HMwkK8kr7uRwVNxnhXsLQsJHxQQYVSzqCAaK58OpJOiTlzbIX7eEwS_VpJ3oEG-xrmVEl2WKqGvB_o-KjyBGTbbjFHM_bN2Jce9g3FTnt2ZJViwcvB9DHPOKPEMCl7jTQRVWKPw_ETloH7_CK8Xr09SSNNx22xnfGjViwdEsGtR-yGrLmr-JUGHA/s1090/bmc-button.png"/></a>


--------------------------------------------------------------------------------------------------------------------

