<!doctype html><html lang="en"> 
    
<head> 
    <meta charset="utf-8"> 
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
 <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous"> 
 <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/uikit@3.5.7/dist/css/uikit.min.css"/> 
 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.0.0/animate.min.css"/> 
 <title>Laravel Point Of sale present by mesinkasironline.web.app</title> 
 
 <style>
 
 @import url('https://fonts.googleapis.com/css2?family=Montserrat:wght@300&display=swap'); html,body{font-family: 'Montserrat', sans-serif;}

</style> 



</head> 

<body class="uk-background-secondary text-center lead text-white"> 
    <div> 
        
    
            <div class="masthead-followup row m-0"> 
                

                      <div class="col-12 col-md-12 p-3 p-md-5"> 
                                        <h1 class="animate__animated display-1 text-light mt-5 animate__rubberBand">
                                            <strong>YuTee ShoP</strong>
                                        </h1> 
                                        <h1 class="animate__animated text-light animate__headShake">InventorY</h1> 
                    
       
                                             
        
        
        
        
                                    <div class="uk-animation-toggle uk-animation-shake">
                                           <a href="/login" class="uk-animation-toggle uk-animation-shake btn btn-light rounded-pill">Get Started →</a> 
                                    </div>
                       </div>
    
             </div>
        
    </div>

                                                                            
                                                                            
                                                                            
                                                                            
                                                                        
                
           
            
            
</body>

</html>