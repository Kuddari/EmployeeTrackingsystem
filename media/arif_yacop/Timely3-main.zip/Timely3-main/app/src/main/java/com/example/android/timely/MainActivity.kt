package com.example.android.timely

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        findViewById<Button>(R.id.loginButton).setOnClickListener {
            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
        }

        findViewById<Button>(R.id.registerButton).setOnClickListener {
            val intent = Intent(this, RegisterActivity::class.java)
            startActivity(intent)


//        // สร้าง DatabaseReference
//        val databaseReference: DatabaseReference = FirebaseDatabase.getInstance().reference
//
//        // เพิ่ม ValueEventListener เพื่อตรวจสอบสถานะการเชื่อมต่อ
//        databaseReference.addValueEventListener(object : ValueEventListener {
//            override fun onDataChange(dataSnapshot: DataSnapshot) {
//                // ทำอะไรก็ตามที่คุณต้องการทำเมื่อมีการเปลี่ยนแปลงข้อมูลในฐานข้อมูล
//                println("เชื่อมต่อกับ Realtime Database สำเร็จ")
//            }
//
//            override fun onCancelled(databaseError: DatabaseError) {
//                // ทำอะไรก็ตามที่คุณต้องการทำเมื่อมีข้อผิดพลาดในการเชื่อมต่อ
//                println("เกิดข้อผิดพลาดในการเชื่อมต่อ: ${databaseError.message}")
//            }
//        })
        }
    }
}
